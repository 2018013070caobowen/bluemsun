function byId(id){
	return typeof(id)=== "string"?document.getElementById(id):id;
}
//全局变量
var timer = null,
    index = 0,
    pics = byId("banner").getElementsByTagName("div"),
    dots = byId("dots").getElementsByTagName("span"),
    prev = byId("prev"),
    next =byId("next"),
	len=pics.length;

function sliderImg(){
	var main=byId("main");
	//滑过清除定时器，离开继续
	main.onmouseover=function(){
		//滑过清除定时器
		if(timer)
		clearInterval(timer);
	}
	main.onmouseout=function(){
		timer = setInterval(function(){
			index++;
			if(index>=len){
				index=0;
			}
		//切换图片
		changeImg();
		},3000);
	}
	//自动在main上触发鼠标离开时间
	main.onmouseout();
	//点击圆点切换
	for(var d=0;d<len;d++){
		//保存d作为dots的索引
		dots[d].id=d;
		dots[d].onclick=function(){
			//改变index为当前span的索引
			index=this.id;
			changeImg();
		}
	}
	//下一张
	next.onclick=function(){
		index++;
		if(index>=len)
		index=0;
		changeImg();
	}
	//上一张
	prev.onclick=function(){
		index--;
		if(index<0) index=len-1;
		changeImg();
	}
}
function changeImg(){
//	遍历所有的banner里的div,将其隐藏
	for(var i=0;i<len;i++){
		pics[i].style.display="none"
		dots[i].className="";
	}
	//根据index索引找到当前div,将其显示
	pics[index].style.display='block';
	dots[index].className="active"
}
sliderImg();